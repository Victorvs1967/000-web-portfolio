// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  baseUrl: 'http://localhost:8088',
  loginUrl: '/auth/login',
  signupUrl: '/auth/signup',
  userUrl: '/api/users',
  projectUrl: '/api/projects',
  imageUrl: '/api/images',
  skillUrl: '/api/skills',
  pageUrl: '/api/pages',
  mailUrl: '/mail/sendmail',
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
