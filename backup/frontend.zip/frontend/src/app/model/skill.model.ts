export interface Skill {
  id: string;
  name: string;
  description: string;
  percent: number;
}
