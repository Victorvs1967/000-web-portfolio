import {
  MatDivider,
  MatDividerModule
} from "./chunk-Y4RFNAZN.js";
import "./chunk-IRMRWSRJ.js";
import "./chunk-L2BZS5YT.js";
import "./chunk-UE5BZ5PP.js";
import "./chunk-3AO7ZCEN.js";
import "./chunk-V7CPLKRG.js";
import "./chunk-U44TYWUZ.js";
import "./chunk-NBZDM5Q7.js";
import "./chunk-PMAS4FRE.js";
import "./chunk-HSWANC32.js";
import "./chunk-WDMUDEB6.js";
export {
  MatDivider,
  MatDividerModule
};
